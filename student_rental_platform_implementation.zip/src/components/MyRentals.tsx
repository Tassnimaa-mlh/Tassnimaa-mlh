import { useQuery } from "convex/react";
import { api } from "../../convex/_generated/api";

export function MyRentals() {
  const rentals = useQuery(api.rentals.listMyRentals);

  if (!rentals) {
    return <div>Chargement...</div>;
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Mes Locations</h2>
      <div className="space-y-4">
        {rentals.map((rental) => (
          <div key={rental._id} className="border rounded-lg p-4">
            <div className="flex justify-between items-start">
              <div>
                <h3 className="text-xl font-semibold">
                  {rental.item?.title}
                </h3>
                <p className="text-slate-600">
                  {new Date(rental.startDate).toLocaleDateString()} -{" "}
                  {new Date(rental.endDate).toLocaleDateString()}
                </p>
                <p className="text-sm text-slate-500">
                  Propriétaire: {rental.owner?.name}
                </p>
              </div>
              <div>
                <span className="inline-block px-3 py-1 rounded-full text-sm font-medium bg-blue-100 text-blue-800">
                  {rental.status}
                </span>
                <p className="mt-2 font-medium">{rental.totalPrice}€</p>
              </div>
            </div>
          </div>
        ))}
        {rentals.length === 0 && (
          <p className="text-center text-slate-500">
            Vous n'avez pas encore de locations
          </p>
        )}
      </div>
    </div>
  );
}
