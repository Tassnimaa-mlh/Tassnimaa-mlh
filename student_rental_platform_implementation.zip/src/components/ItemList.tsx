import { useState } from "react";
import { useQuery, useMutation } from "convex/react";
import { api } from "../../convex/_generated/api";
import { toast } from "sonner";
import { Id } from "../../convex/_generated/dataModel";

const CATEGORIES = [
  "Livres",
  "Électronique",
  "Vêtements",
  "Outils",
  "Sport",
  "Autres",
];

export function ItemList() {
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  
  const items = useQuery(api.items.list, {
    category: selectedCategory ?? undefined,
    searchQuery: searchQuery || undefined,
  });

  const requestRental = useMutation(api.rentals.request);

  const handleRentRequest = async (itemId: Id<"items">) => {
    try {
      const startDate = Date.now();
      const endDate = startDate + 7 * 24 * 60 * 60 * 1000; // 7 days rental
      await requestRental({ itemId, startDate, endDate });
      toast.success("Demande de location envoyée !");
    } catch (error) {
      toast.error("Erreur lors de la demande de location");
    }
  };

  if (!items) {
    return <div>Chargement...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex gap-4 items-center">
        <input
          type="text"
          placeholder="Rechercher un objet..."
          className="flex-1 p-2 border rounded"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
        <select
          className="p-2 border rounded"
          value={selectedCategory ?? ""}
          onChange={(e) => setSelectedCategory(e.target.value || null)}
        >
          <option value="">Toutes catégories</option>
          {CATEGORIES.map((cat) => (
            <option key={cat} value={cat}>
              {cat}
            </option>
          ))}
        </select>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {items.map((item) => (
          <div key={item._id} className="border rounded-lg p-4 space-y-4">
            {item.imageUrl && (
              <img
                src={item.imageUrl}
                alt={item.title}
                className="w-full h-48 object-cover rounded"
              />
            )}
            <div>
              <h3 className="text-xl font-semibold">{item.title}</h3>
              <p className="text-slate-600">{item.description}</p>
              <p className="font-medium">{item.pricePerDay}€ / jour</p>
              <p className="text-sm text-slate-500">
                Proposé par {item.owner?.name}
              </p>
            </div>
            <button
              onClick={() => handleRentRequest(item._id)}
              className="w-full bg-blue-500 text-white py-2 rounded hover:bg-blue-600"
            >
              Demander à louer
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
