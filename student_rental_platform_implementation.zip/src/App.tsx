import { Authenticated, Unauthenticated } from "convex/react";
import { api } from "../convex/_generated/api";
import { SignInForm } from "./SignInForm";
import { SignOutButton } from "./SignOutButton";
import { Toaster } from "sonner";
import { ItemList } from "./components/ItemList";
import { MyRentals } from "./components/MyRentals";

export default function App() {
  return (
    <div className="min-h-screen flex flex-col">
      <header className="sticky top-0 z-10 bg-white/80 backdrop-blur-sm p-4 flex justify-between items-center border-b">
        <h2 className="text-xl font-semibold accent-text">Stud'Loc</h2>
        <SignOutButton />
      </header>
      <main className="flex-1 p-8">
        <div className="max-w-7xl mx-auto">
          <Content />
        </div>
      </main>
      <Toaster />
    </div>
  );
}

function Content() {
  return (
    <div className="space-y-8">
      <div className="text-center">
        <h1 className="text-5xl font-bold accent-text mb-4">Stud'Loc</h1>
        <p className="text-xl text-slate-600">
          Location d'objets entre étudiants
        </p>
      </div>

      <Unauthenticated>
        <div className="max-w-md mx-auto">
          <SignInForm />
        </div>
      </Unauthenticated>

      <Authenticated>
        <div className="space-y-12">
          <ItemList />
          <MyRentals />
        </div>
      </Authenticated>
    </div>
  );
}
