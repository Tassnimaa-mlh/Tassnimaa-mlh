import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";

export const list = query({
  args: {
    category: v.optional(v.string()),
    searchQuery: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    if (args.searchQuery) {
      return await ctx.db
        .query("items")
        .withSearchIndex("search", (q) => q.search("title", args.searchQuery!))
        .collect()
        .then(async (items) => {
          return Promise.all(
            items.map(async (item) => {
              const owner = await ctx.db.get(item.ownerId);
              return { ...item, owner };
            })
          );
        });
    }
    
    const items = await ctx.db
      .query("items")
      .withIndex("by_category", (q) => 
        args.category ? q.eq("category", args.category) : q
      )
      .collect();
    
    return Promise.all(
      items.map(async (item) => {
        const owner = await ctx.db.get(item.ownerId);
        return { ...item, owner };
      })
    );
  },
});

export const create = mutation({
  args: {
    title: v.string(),
    description: v.string(),
    category: v.string(),
    pricePerDay: v.number(),
    imageUrl: v.optional(v.string()),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    return await ctx.db.insert("items", {
      ownerId: userId,
      title: args.title,
      description: args.description,
      category: args.category,
      pricePerDay: args.pricePerDay,
      imageUrl: args.imageUrl,
      available: true,
    });
  },
});
