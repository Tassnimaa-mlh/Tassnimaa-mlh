import { v } from "convex/values";
import { mutation, query } from "./_generated/server";
import { getAuthUserId } from "@convex-dev/auth/server";
import { Doc, Id } from "./_generated/dataModel";

export const request = mutation({
  args: {
    itemId: v.id("items"),
    startDate: v.number(),
    endDate: v.number(),
  },
  handler: async (ctx, args) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) throw new Error("Not authenticated");

    const item = await ctx.db.get(args.itemId);
    if (!item) throw new Error("Item not found");
    if (!item.available) throw new Error("Item not available");

    const days = Math.ceil((args.endDate - args.startDate) / (1000 * 60 * 60 * 24));
    const totalPrice = days * item.pricePerDay;

    return await ctx.db.insert("rentals", {
      itemId: args.itemId,
      renterId: userId,
      startDate: args.startDate,
      endDate: args.endDate,
      status: "pending",
      totalPrice,
    });
  },
});

export const listMyRentals = query({
  handler: async (ctx) => {
    const userId = await getAuthUserId(ctx);
    if (!userId) return [];

    const rentals = await ctx.db
      .query("rentals")
      .withIndex("by_renter", (q) => q.eq("renterId", userId))
      .collect();

    return Promise.all(
      rentals.map(async (rental: Doc<"rentals">) => {
        const item = await ctx.db.get(rental.itemId);
        const owner = item ? await ctx.db.get(item.ownerId) : null;
        return { ...rental, item, owner };
      })
    );
  },
});
