import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";
import { authTables } from "@convex-dev/auth/server";

const applicationTables = {
  profiles: defineTable({
    userId: v.id("users"),
    name: v.string(),
    university: v.string(),
    bio: v.optional(v.string()),
  }).index("by_user", ["userId"]),

  items: defineTable({
    ownerId: v.id("users"),
    title: v.string(),
    description: v.string(),
    category: v.string(),
    pricePerDay: v.number(),
    available: v.boolean(),
    imageUrl: v.optional(v.string()),
  })
    .index("by_owner", ["ownerId"])
    .index("by_category", ["category"])
    .searchIndex("search", {
      searchField: "title",
      filterFields: ["category", "available"],
    }),

  rentals: defineTable({
    itemId: v.id("items"),
    renterId: v.id("users"),
    startDate: v.number(),
    endDate: v.number(),
    status: v.string(), // pending, approved, active, completed, cancelled
    totalPrice: v.number(),
  })
    .index("by_renter", ["renterId"])
    .index("by_item", ["itemId"]),
};

export default defineSchema({
  ...authTables,
  ...applicationTables,
});
